from flask_sqlalchemy import SQLAlchemy
from flask_admin import Admin
from sqlalchemy import UniqueConstraint


db = SQLAlchemy()
admin = Admin()


class Bands(db.Model):
    BandID = db.Column(db.Integer, primary_key=True)
    BandName = db.Column(db.String(80), nullable=False)
    FormedYear = db.Column(db.Integer)
    HomeLocation = db.Column(db.String(80))
    memberships = db.relationship('Memberships', backref='band', lazy=True,
                                   cascade='all, delete-orphan')
    band_album = db.relationship('Band_Album', back_populates='band', lazy=True,
                                  cascade='all, delete-orphan')


class Members(db.Model):
    MemberID = db.Column(db.Integer, primary_key=True)
    MemberName = db.Column(db.String(80), nullable=False)
    MainPosition = db.Column(db.String(80))
    memberships = db.relationship('Memberships', backref='member', lazy=True,
                                   cascade='all, delete-orphan')


class Memberships(db.Model):
    MembershipID = db.Column(db.Integer, primary_key=True)
    BandID = db.Column(db.Integer, db.ForeignKey('bands.BandID'), nullable=False)
    MemberID = db.Column(db.Integer, db.ForeignKey('members.MemberID'), nullable=False)
    Role = db.Column(db.String(80))
    StartYear = db.Column(db.Integer)
    EndYear = db.Column(db.Integer)


class Albums(db.Model):
    AlbumID = db.Column(db.Integer, primary_key=True)
    AlbumTitle = db.Column(db.String(80), nullable=False)
    ReleaseYear = db.Column(db.Integer)
    band_album = db.relationship('Band_Album', back_populates='album', lazy=True,
                                  cascade='all, delete-orphan')


class Band_Album(db.Model):
    __table_args__ = (UniqueConstraint('BandID', 'AlbumID', name='uq_band_album'),)

    Band_AlbumID = db.Column(db.Integer, primary_key=True)
    AlbumID = db.Column(db.Integer, db.ForeignKey('albums.AlbumID'), nullable=False)
    BandID = db.Column(db.Integer, db.ForeignKey('bands.BandID'), nullable=False)
    band = db.relationship('Bands', back_populates='band_album')
    album = db.relationship('Albums', back_populates='band_album')
