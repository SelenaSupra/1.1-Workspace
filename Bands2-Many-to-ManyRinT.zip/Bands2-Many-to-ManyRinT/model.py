from flask_sqlalchemy import SQLAlchemy
from flask_admin import Admin

db = SQLAlchemy()

admin = Admin()


class Bands(db.Model):
    BandID = db.Column(db.Integer, primary_key=True)
    BandName = db.Column(db.String(80), nullable=False)
    FormedYear = db.Column(db.Integer)
    HomeLocation = db.Column(db.String(80))
    # Removed members relationship in favor of memberships
    # members = db.relationship('Members', backref='band', lazy=True)
    memberships = db.relationship('Memberships', backref='band', lazy=True)
    #albums = db.relationship('Albums', backref='band', lazy=True)
    artists = db.relationship('Artists', backref='band', lazy=True)
    #band_album = db.relationship('Band_Album', backref='band', lazy=True )


class Members(db.Model):
    MemberID = db.Column(db.Integer, primary_key=True)
    # Removed BandID
    # BandID = db.Column(db.Integer, db.ForeignKey('band.BandID'), nullable=False)
    MemberName = db.Column(db.String(80), nullable=False)
    MainPosition = db.Column(db.String(80))
    # Add relationship to memberships table
    memberships = db.relationship('Memberships', backref='member', lazy=True)


class Memberships(db.Model):
    MembershipID = db.Column(db.Integer, primary_key=True)
    BandID = db.Column(db.Integer, db.ForeignKey('bands.BandID'), nullable=False)
    MemberID = db.Column(db.Integer, db.ForeignKey('members.MemberID'), nullable=False)
    Role = db.Column(db.String(80))
    StartYear = db.Column(db.Integer)
    EndYear = db.Column(db.Integer)


class Albums(db.Model):
    AlbumID = db.Column(db.Integer, primary_key=True)
    #BandID = db.Column(db.Integer, db.ForeignKey('bands.BandID'), nullable=False)
    AlbumTitle = db.Column(db.String(80), nullable=False)
    ReleaseYear = db.Column(db.Integer)
    artists = db.relationship('Artists', backref='album', lazy=True)
    #band_album = db.relationship('Band_Album', backref='album', lazy=True)    


class Artists(db.Model):
    ArtistID = db.Column(db.Integer, primary_key=True)
    BandID = db.Column(db.Integer, db.ForeignKey('bands.BandID'), nullable=False)
    AlbumID = db.Column(db.Integer, db.ForeignKey('albums.AlbumID'), nullable=False)
    

# class Band_Albums(db.Model):
#     Band_AlbumID = db.Column(db.Integer, primary_key=True)
#     BandID = db.Column(db.Integer, db.ForeignKey('bands.BandID'), nullable=False)
#     AlbumID = db.Column(db.Integer, db.ForeignKey('albums.AlbumID'), nullable=False)

